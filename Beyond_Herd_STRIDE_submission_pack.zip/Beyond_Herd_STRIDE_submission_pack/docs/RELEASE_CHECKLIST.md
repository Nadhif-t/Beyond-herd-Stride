# Release checklist for the STRIDE replication repository

1. Confirm that the Python scripts are the exact files used for the manuscript revision.
2. Run `python calibrate.py data/prosperLoanData.csv configs/calib.json` with the intended dataset.
3. Record the SHA-256 digest printed by the calibration script.
4. Confirm that no experiment silently uses the fallback calibration.
5. Run the complete workflow without `--quick`.
6. Archive `configs/calib.json`, `configs/tau.json`, `configs/tuned.json`, all replication-level CSVs, Python version, and dependency versions.
7. Recompute every table and figure from the archived outputs.
8. Check statistical interpretations, especially equivalence intervals and unresolved comparisons.
9. Document all source-code assumptions and any deviations from the manuscript.
10. Do not upload the Prosper raw CSV unless redistribution is permitted.
