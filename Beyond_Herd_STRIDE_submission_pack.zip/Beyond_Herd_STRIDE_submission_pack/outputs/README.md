# Generated experiment outputs

The experiment driver writes stage-specific CSV files to this directory (or to the path supplied with `--out`). Preserve the full replication-level outputs used to compute the manuscript tables and figures. Do not commit large generated outputs automatically; decide which files to archive or publish after checking repository size and data/licensing constraints.
