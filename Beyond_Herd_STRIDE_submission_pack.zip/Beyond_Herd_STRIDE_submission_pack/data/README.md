# Data directory

Place the source dataset here as `prosperLoanData.csv`.

The raw Prosper dataset is intentionally not included in this package. Obtain it from the source or mirror documented in the manuscript and verify that redistribution/use is permitted. The calibration command is:

```bash
python calibrate.py data/prosperLoanData.csv configs/calib.json
```

The script prints the SHA-256 digest of the input file. Archive that digest with your experiment records.
