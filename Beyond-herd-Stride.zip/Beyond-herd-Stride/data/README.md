# Data

The Prosper loan file (`prosperLoanData.csv`, 113,937 loans, 81 columns) is **not redistributed** here.
Download it from a public mirror, place it in this folder, then run:

    python calibrate.py data/prosperLoanData.csv configs/calib.json

`calibrate.py` selects the resolved 36-month loans listed 2009-07-01 to 2011-03-01 (Completed, Chargedoff, Defaulted),
and writes `configs/calib.json`. The cell table (sample sizes, defaults, Wilson 95% intervals) is `configs/calib_cells.csv`.

Expected output on the file used to prepare this package: 8,676 loans, 5,645 first-time borrowers (65.06%),
first-time/repeat default ratio 1.34 (loan-level percentile bootstrap 1.21–1.50), log-sd of loan size 0.755.

Checksum: the manuscript quotes the SHA-256 of the authors' copy (starts `71c1c193…cce0f`). The copy used to
regenerate `configs/calib.json` in this package has SHA-256
`fce13408ac22e8201363e71e1a16d9795305f4aaf8c0f67efcd80424bc5b9e02`; both copies give identical counts.
Verify your own copy with `sha256sum prosperLoanData.csv` and replace the checksum in the manuscript by the value of the copy you used.
