"""Compare regenerated outputs with the numbers printed in the manuscript (reported/*.csv).

Usage:  python run_all.py --stage tau && python run_all.py --stage main
        python verify_against_manuscript.py [--tol 2.0]

For Table 3 (main comparison) and Table 4 (paired differences) it prints, for each policy and metric, the
value reported in the manuscript, the value regenerated here, and PASS/FAIL (|difference| <= tol, in
percentage points). The script exits with status 1 if any check fails, so that the repository can only be
described as reproducing the manuscript when this script passes."""
import argparse, re, sys
import pandas as pd

MAP = {'Random': 'Random', 'Popularity': 'Popularity', 'CF (SVD)': 'Cf', 'Content': 'Content', 'Hybrid (reference)': 'Hybrid',
       'PopPenalty': 'PopPenalty', 'UCB-Explore': 'UCB', 'Quota (young listings)': 'Quota', 'NewQuota (first-time)': 'NewQuota',
       'ExpCap': 'ExpCap', 'STRIDE (static)': 'STRIDE', 'STRIDE, uniform Stranger': 'STRIDE-uniform', 'STRIDE, shuffled Stranger': 'STRIDE-shuffled'}
T3 = {'NPSR': 'npsr', 'Solvent new funded': 'solvent', 'Funded volume': 'volume', 'Incumbents funded': 'incumbents'}
T4 = {'Δ NPSR': 'd_npsr', 'Δ Solvent new funded': 'd_solvent', 'Δ Volume': 'd_volume'}

def num(s):
    m = re.match(r'\s*([+\-−]?)\s*([0-9.]+)', str(s))
    return None if not m else (-1 if m.group(1) in ('-', '−') else 1) * float(m.group(2))

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--tol', type=float, default=2.0); ap.add_argument('--out', default='outputs'); A = ap.parse_args()
    got = pd.read_csv(f'{A.out}/table3_4.csv').set_index('policy'); bad = 0; n = 0
    for fn, cols in (('reported/table3_main.csv', T3), ('reported/table4_paired.csv', T4)):
        rep = pd.read_csv(fn)
        for _, r in rep.iterrows():
            pol = MAP.get(r['Policy'])
            if pol not in got.index: continue
            for col, key in cols.items():
                if col not in rep.columns: continue
                a = num(r[col]); b = got.loc[pol, key]
                if a is None or pd.isna(b): continue
                n += 1; ok = abs(a - b) <= A.tol; bad += (not ok)
                print(f'{"PASS" if ok else "FAIL"}  {r["Policy"]:<28}{col:<22} manuscript {a:7.1f}   regenerated {b:7.1f}')
    print(f'\n{n - bad}/{n} checks within ±{A.tol} pp')
    sys.exit(1 if bad else 0)

if __name__ == '__main__': main()
