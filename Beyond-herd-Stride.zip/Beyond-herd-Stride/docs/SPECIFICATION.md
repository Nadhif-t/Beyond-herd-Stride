# Simulator and implementation specification (Table 9 of the manuscript)

## Investor sector affinities

Eight sectors. The affinity vector of each investor has independent entries drawn from U(0, 1), fixed for the whole replication. Each listing belongs to one sector drawn uniformly over the eight; the affinity enters the choice utility through a[u, sector(i)].

## Latent novelty preference ζ and explorer status

Explorer status is an independent Bernoulli draw per investor with probability equal to the explorer share (reference 0.25; 0, 0.10 and 0.40 in the scenarios of Table 7). Explorers have ζ ~ U(0.7, 1) and all other investors ζ ~ U(0, 0.3); ζ is fixed during the replication and never observed by the recommender.

## Initial investment histories

No history is pre-loaded. At day 0 the investor–listing matrix, the sector counts and the three Stranger signals are empty (CF score zero on day 0, content score reduced to its credit-grade term). Histories are built only by the 20-day common burn-in under Hybrid (days 0–19), which all policies share; the policy under test is applied from day 20.

## Ticket budgets and loan-size clipping

Loan amounts have a log-standard deviation of 0.755 (0.67 after clipping). Amount = median 15 · exp(0.755 z), z ~ N(0, 1), clipped to [3, 60] ticket units (median 10 and 25 in the loan-size scenarios). One ticket is one unit, so a listing needs m = max(2, round(amount)) tickets. Each investor commits at most one ticket per listing and has a budget of 2 tickets per day, renewed every day (no carry-over and no depletion of capital by lock-up).

## Score shrinkage priors

Three pseudo-observations. For each signal x (entropy, RCS, SAP) the shrunk value is (n·x + 3·x̄) / (n + 3), with n the number of past investments of the investor and x̄ the population prior, equal to the mean of the signal over investors with at least one investment on that day (0.5 if there is none). Entropy is normalised by ln 8. An investor without history receives x̄ for each signal. pop(i) and the listing age are those at investment time.

## Daily event order

Each day t: (1) listings created on day t join the open set and listings whose window has ended unfunded (created on day t − 14) are closed and their commitments released; (2) pop(i), listing ages and the Inew/Itail sets are computed from the counts at the start of the day and stay fixed during the day; (3) every third day (t > 0) the SVD is refreshed; (4) scores are computed and each investor receives a list of K = 10 listings not yet financed by that investor; (5) list positions are processed one after another, k = 1 to K: an investor with remaining budget takes the listing at position k with probability σ(u)/(1 + 0.25(k − 1)); (6) within a position, investors are processed in random order and a listing accepts commitments until its m tickets are reached (the surplus investors are rejected and keep their budget); a listing that reaches m is funded that day and leaves the open set. Ties in scores are broken by the lower index (stable sort). Investor-level histories are updated after each position.

## SVD folding and content score

Rank 12, refresh every three days. The matrix is binary (1 if investor u committed a ticket to listing i, otherwise 0), investors × all listings created so far, with no weighting and no time decay; it is rebuilt from the full history at each refresh (days 3, 6, …) and truncated with rank min(12, dimension − 1). Only the left singular vectors U are kept: the CF score of an open listing is U Uᵀ c_i, the projection of its current column of investors c_i, updated daily (fold-in); a listing without investors scores zero. Both CF and content scores are min–max normalised per investor over the open listings, and a constant vector is mapped to zero. The content score is the share of u’s past investments in the sector of i plus 0.5 · qi, where qi = clip(1 − d / 0.3, 0.05, 0.95) is the credit-grade term and d the realised default rate of the (type, grade) cell of the listing (not its latent PD). The coefficient 0.5 on the grade is the one of the choice utility.

## Quotas and impression cap

Quota rounding: r = round(q · K) reserved slots (K = 10, so q = 0.6 gives 6 and q = 0.8 gives 8; ties rounded to the even integer). The r slots go to the best-scoring valid listings of the protected group (age at most five days for Quota; first-time borrowers for NewQuota); if fewer than r exist, the shortage is filled with the best remaining listings. The final list is ordered by the Hybrid score, with no protected block at the top. ExpCap: the daily cap is c · U · K / n_open, that is c times the mean number of impressions per open listing, where n_open is the number of listings open that day; the investors are split in eight random batches, a listing is removed from the candidates of a batch once its impressions of the day reach the cap (checked at the start of each batch, so a batch may exceed it), and the counters are reset to zero at the start of each day.

## Tuning grids and budget

Grids (value 0 or no cap = Hybrid): STRIDE w₃ ∈ {0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.40}; PopPenalty λ ∈ {0.05, 0.1, 0.2, 0.3, 0.5}; UCB c ∈ {0.05, 0.1, 0.2, 0.4}; Quota q ∈ {0.2, 0.4, 0.6, 0.8}; NewQuota q ∈ {0.4, 0.6, 0.8, 0.9, 1.0}; ExpCap cap ∈ {2, 3, 5, 8}. Budget: 29 settings × 4 replications (seeds 101–104) = 116 runs, plus the Hybrid reference on the same seeds; rule: maximise the funded share of creditworthy first-time demand subject to funded volume at least 97% of Hybrid. Selected: w₃ = 0.2, λ = 0.1, c = 0.1, q = 0.6 (Quota), q = 0.8 (NewQuota), cap = 5. The capital-scarcity τ is found by bisection on [0, 4] with nine halvings (resolution about 0.008) on seeds 900–902, targeting a Hybrid funded volume of 55%.

## Default-rate conversion

Realised cell default rate with lognormal dispersion (sd 0.25). The dispersion is mean-preserving: PD = d · exp(0.25 z − 0.25²/2), z ~ N(0, 1), with d the cell default rate, and PD is clipped at 0.95. For the highest cell rates (up to about 0.30) the probability that PD exceeds 0.95 is of the order of 10⁻⁶, so clipping does not change the calibrated moments (simulated mean 0.0400 for d = 0.04, 0.1840 for d = 0.184 and 0.3000 for d = 0.30). Cell sizes, defaults and Wilson 95% intervals are written to calibration_cells.csv by the calibration script (5,645 first-time and 3,031 repeat loans in total). The interval of the first-time / repeat ratio of 1.34 (1.21–1.50) is a loan-level percentile bootstrap: loans of each type are resampled with replacement, 2,000 resamples, seed 0, 2.5th and 97.5th percentiles of the ratio of the two mean default rates.

## Global sensitivity ranges

Draws (seed 2026) are uniform and independent, in this order: κ ∈ [0.5, 3.5]; ν ∈ [0.6, 1.8]; explorer share ∈ [0, 0.4]; listings per day ∈ [30, 55]; position-bias decay ∈ [0.1, 0.5]; median loan size ∈ [10, 25]; share of first-time borrowers ∈ [0.5, 0.8]; PD dispersion sd ∈ [0.1, 0.5]; grade weight ∈ [0, 1]; track-record strength n₀ ∈ [5, 25]. Each of the 24 draws is simulated with seeds 400 + 10d + {0, 1, 2} and all other parameters at their reference values.

## Equal-volume estimator

See Section 5.3. For a STRIDE weight w₃, the target volume is the mean funded volume of STRIDE over the 16 frontier replications (6 for the benchmark). The comparator curve is the mean (volume, metric) pair of each grid value, including its Hybrid starting point, ordered by volume; the metric is linearly interpolated at the target. The bracket is the pair of comparator parameter values and volumes enclosing the target, and the volume mismatch is the distance between the target and the nearest comparator grid volume. A comparison is unresolved if the target lies outside the curve or if the curve crosses it more than once. The bootstrap resamples replication seeds with replacement, jointly for all policies and settings, repeats the interpolation inside each resample (resamples with a non-valid interpolation are discarded and their number is reported), and uses 1,000 resamples, seed 0, with the 2.5th and 97.5th percentiles. The verdict follows the ±2 pp rule of Section 5.3 (±1 pp as sensitivity check).
