# Seeds and configurations (Table 8 of the manuscript)

| Purpose | Seeds | Configuration |
|---|---|---|
| Calibration of τ (Hybrid, 55% volume) | 900–902 | τ = 1.179 (Prosper), 1.026 (benchmark) |
| Hyper-parameter tuning | 101–104 | Grids in run_all.py; rule: max solvent funded subject to volume ≥ 97% of Hybrid |
| Main evaluation | 1–30 | tuned.json; 13 policies; both calibrations |
| Frontiers and equal-volume comparison | 201–216 (benchmark 201–206) | w₃, λ, c, q and cap grids; bootstrap seed 0, 1,000 resamples |
| Scenarios | 301–305 | 27 configurations (SCEN in run_all.py) |
| Global sensitivity | 400 + 10d + {0,1,2}, d = 0–23 | parameter draws with seed 2026 |
| Random streams | (s,0), (s,1000+t), (s,5000+t), (s,7000+t) | world; daily choices; SVD sketch; ExpCap batches |
