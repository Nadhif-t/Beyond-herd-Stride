# Before making the repository public

1. Put the simulator that produced the manuscript tables in `sim.py` (or add it beside it) and run
   `python verify_against_manuscript.py`; publish only when it passes, or state precisely which results are not reproduced.
2. Regenerate `configs/tuned.json` (`--stage tune`) and `configs/tau.json` with that simulator.
3. Run all stages and commit the outputs: `frontier` (Tables 5–6), `scenarios` (Table 7), `global`.
4. Check that the manuscript's Data and Code Availability section lists only files present in the repository.
5. Replace the dataset checksum in the manuscript by that of the copy you actually used (`data/README.md`).
6. Add a licence file of your choice and a release tag; cite it in the manuscript.
