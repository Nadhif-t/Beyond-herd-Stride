# Beyond the Herd — STRIDE and simple baselines in a Prosper-calibrated lending marketplace simulator

Code, configuration and reference material accompanying the manuscript *Beyond the Herd: When Does Exposure
Redistribution Reduce Credit Rationing of First-Time Borrowers?*

## Reproduction status (read first)

`verify_against_manuscript.py` compares the regenerated main comparison with the numbers printed in the
manuscript (Tables 3 and 4). **With the `sim.py` shipped in this folder, 27 of 76 checks pass**
(`outputs/verification_report.txt`, 30 evaluation seeds, calibration of this package):

* Reproduced within ±2 pp: the Hybrid reference (NPSR 49.0 vs 50.8, volume 54.6 vs 55.3, incumbents 68.2 vs 66.8),
  the age-based Quota, ExpCap, and the NPSR of NewQuota (61.3 vs 62.0, paired gain +12.2 vs +11.3).
* **Not reproduced:** the gains of STRIDE (+0.6 vs +15.7 pp NPSR), PopPenalty (+0.2 vs +12.9) and UCB-Explore
  (+0.3 vs +13.9), and therefore the incumbent-funding figures that depend on them.

`sim.py` is a reconstruction of the simulator from the written specification (`docs/SPECIFICATION.md`); components
whose value is not fixed by the text are marked `[ASSUMED]`. **The numerical results of the manuscript must not be
described as reproduced by this code until `verify_against_manuscript.py` passes.** Replace `sim.py` by the
simulator that produced the manuscript tables (keeping the interface `run(params, seed, policy, param, variant)`
used by `run_all.py`) and re-run the verification.

## Contents

| Path | Role |
|---|---|
| `calibrate.py` | Loan-side calibration from the Prosper file → `configs/calib.json`, `configs/calib_cells.csv` |
| `sim.py` | Marketplace simulator (see status above) |
| `run_all.py` | Experiment driver: stages `tau`, `tune`, `main`, `frontier`, `scenarios`, `global` (`--quick` for a smoke test) |
| `stride_analysis.py` | Equal-volume estimator, similarity verdicts, volume margins, calibration cells, newness overlap, score-quality check |
| `verify_against_manuscript.py` | Regenerated vs printed numbers (Tables 3–4) |
| `configs/` | `calib.json`, `calib_cells.csv` (generated from Prosper), `manuscript_settings.json` (values stated in the manuscript), `tuned.json` (selected intensities reported in the manuscript), `tau.json` (calibrated for **this** `sim.py`; the manuscript's value 1.179 belongs to the original run) |
| `reported/` | Tables 2–7 of the manuscript transcribed as CSV (provenance: the manuscript, not outputs of this code) |
| `docs/` | `SPECIFICATION.md` (Table 9), `SEEDS.md` (Table 8), `table8_seeds.csv`, `table9_specification.csv`, `RELEASE_CHECKLIST.md` |
| `outputs/` | Outputs of the run described above: `main.csv` (per-replication), `table3_4.csv`, `volume_margins_eval.csv`, `verification_report.txt` |
| `data/` | Instructions for the Prosper file (not redistributed) and checksum note |

## Run

    pip install -r requirements.txt
    python calibrate.py data/prosperLoanData.csv configs/calib.json
    python run_all.py --stage tau          # calibrate tau so that Hybrid funds ~55% of volume
    python run_all.py --stage main         # 13 policies x 30 seeds (about 25 minutes on one core)
    python verify_against_manuscript.py
    python run_all.py --stage all --quick  # fast smoke test

Seeds, grids and the tuning rule are in `docs/SEEDS.md` and `configs/manuscript_settings.json`.
The Prosper file is not redistributed; see `data/README.md`.
