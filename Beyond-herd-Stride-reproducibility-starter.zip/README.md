# Beyond-herd-Stride — Reproducibility package (starter scaffold)

This archive is a **starter scaffold**, not a complete runnable replication package.
It was assembled from the manuscript `Brevisednazif_corrected1.docx`. The actual simulator,
calibration scripts, Prosper source data, outputs, and full source checksum were not present
in the materials available to build this archive.

## What is needed for a full reproduction
1. Obtain the simulator implementation and scripts from the authors' GitHub repository.
2. Obtain `prosperLoanData.csv` from its public source (the manuscript says the data are not redistributed).
3. Verify the source CSV against the full SHA-256 checksum, which the manuscript says is included
   in the complete replication package (the manuscript text only shows a truncated checksum).
4. Fill the TODOs in `src/`, `configs/`, and `docs/`, then execute the commands documented there.
5. Archive raw inputs, generated results, and logs for the reproduction.

## Manuscript protocol summarized
- Marketplace: 1,200 investors; Poisson(42) new listings/day; 14-day listing window;
  80-day horizon; 20-day Hybrid burn-in; evaluation listings created days 20–63.
- Main evaluation: seeds 1–30. Tuning: seeds 101–104. Calibration of scarcity parameter:
  seeds 900–902. Frontiers: seeds 201–216 (benchmark uses 201–206). Scenarios: 301–305.
  Global sensitivity: 24 draws, draw seed 2026; replication seeds `400 + 10*d + {0,1,2}`.
- Within replication random streams: `(s,0)` world generation; `(s,1000+t)` daily investor choices;
  `(s,5000+t)` SVD sketch; `(s,7000+t)` ExpCap batches.
- Prosper calibration window: 36-month loans listed July 2009–February 2011, resolved loans,
  with 8,676 loans. Public Prosper data file is cited as `prosperLoanData.csv` (113,937 loans,
  2005–2014) and is not included in this archive.
- Reference parameters noted in the manuscript: 1,200 investors, 42 listings/day,
  14-day window, 80-day horizon, 20-day burn-in; first-time share 0.651; LGD 0.63;
  loan-size log-SD 0.755 (0.67 after clipping); PD dispersion SD 0.25; investor grade noise 0.4;
  capital scarcity `tau=1.18` (Prosper calibration); reference `kappa=2`, `nu=1.2`;
  position bias 0.25; list length K=10; STRIDE `w3=0.2`; PopPenalty `lambda=0.1`;
  UCB `c=0.1`; Quota `q=0.6`; NewQuota `q=0.8`; ExpCap 5× mean exposure.

## Folder map
- `data/raw/` — place source data here (not included)
- `data/processed/` — calibration extracts and intermediate files
- `src/` — implementation scripts (not included; TODO stubs provided)
- `configs/` — configuration files and tuning grids
- `results/` — reproduced tables and figures
- `tests/` — checks for implementation and data
- `docs/` — replication notes and data/checksum instructions

## Status
This package is not yet sufficient to reproduce the paper. Use the checklist in `docs/replication_checklist.md`
to track what must be added from the actual GitHub repository and verified.
