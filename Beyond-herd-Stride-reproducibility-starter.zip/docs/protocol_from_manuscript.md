# Replication protocol extracted from the manuscript

**Important:** this is a transcription/organization of reported settings, not executable code.
The full implementation details, tuning grids and data checksum must be recovered from the repository/package.

## Experiment design and seeds
- Calibration of tau: seeds 900–902.
- Hyperparameter tuning: seeds 101–104; maximize funded share of creditworthy first-time-borrower demand, subject to funded volume >=97% of Hybrid.
- Main evaluation: seeds 1–30; policies include 13 configurations and both calibration variants.
- Frontiers/equal-volume: seeds 201–216 (benchmark: 201–206); bootstrap seed 0, 1,000 resamples.
- Scenarios: seeds 301–305, 27 configurations.
- Global sensitivity: 24 parameter draws, draw seed 2026; replication seeds `400 + 10*d + {0,1,2}` for d=0..23.

## Simulator
- 1,200 investors; Poisson(42) new listings/day.
- 14-day listing window; 80-day simulation; 20-day common Hybrid burn-in.
- Evaluation listings created days 20–63; approximately 1,850 listings/replication.
- K=10 recommendations per investor/day.
- Investor position probability: `sigma(u) / (1 + 0.25*(k-1))`.
- Choice utility: sector affinity + 0.5*grade + kappa*(1-zeta)*pop + nu*zeta*1[new], with reference kappa=2 and nu=1.2.
- Eight sectors; investor-sector affinities independently U(0,1), fixed per replication.
- Explorer share reference 0.25; explorers zeta~U(0.7,1), others U(0,0.3).
- One ticket per investor/listing; budget two tickets/day, renewed daily.
- Listing ticket target m=max(2, round(amount)); loan amount uses median 15 and log-SD 0.755, clipped [3,60] (loan-size scenarios use medians 10 and 25).
- Score shrinkage: three pseudo-observations; normalized entropy by ln(8).
- SVD: rank 12, refresh every three days; binary investor-listing matrix, no time decay.
- ExpCap: cap = c*U*K/n_open; eight random investor batches.

## Loan calibration notes
- Prosper source dataset described as 113,937 loans (2005–2014), not redistributed.
- Calibration sample: 8,676 resolved 36-month loans listed Jul 2009–Feb 2011.
- First-time borrower definition: `TotalProsperLoans` empty.
- First-time share: 0.651; first-time default 18.4%; repeat default 13.7%; ratio 1.34.
- LGD 0.63; loan amount log-SD 0.755 (parameter; 0.67 after clipping).
- PD dispersion lognormal SD 0.25; grade observation logit noise SD 0.4.
- Creditworthy threshold: PD <= 15%.
- Prosper tau=1.18 (manuscript reports recalibration value); benchmark tau=1.026.
- Calibration seeds 900–902.

## Policy settings reported
- STRIDE w3=0.2
- PopPenalty lambda=0.1
- UCB c=0.1
- Quota q=0.6 (young listings <=5 days)
- NewQuota q=0.8 (first-time borrowers)
- ExpCap: cap 5 times mean exposure
- Hybrid baseline

## Random stream mapping
- `(s,0)`: world/investor/listing generation
- `(s,1000+t)`: daily investor choices
- `(s,5000+t)`: SVD sketch
- `(s,7000+t)`: ExpCap batches

## Reproduction outputs to populate
- Tables 3–7 and Figures 2–3
- per-replication outcomes, borrower-type/grade counts
- rates, default estimates, uncertainty calculations
- selected tuned configurations, tuning grids, sensitivity ranges and realised draws
