# Completion checklist

## Not yet included / must be recovered or verified
- [ ] Simulator source code and entry point
- [ ] Calibration/preprocessing scripts
- [ ] Prosper source file and source URL/licence details (not redistributed in paper)
- [ ] Full SHA-256 checksum of source CSV (manuscript checksum is abbreviated)
- [ ] Exact tuning grids and selected configurations (including benchmark settings)
- [ ] Sensitivity parameter ranges and realised draws
- [ ] Seed-to-stream implementation
- [ ] Per-replication outputs underlying Tables 3–7 and Figures 2–3
- [ ] Borrower-type and grade counts; rates/default estimates
- [ ] Statistical/uncertainty calculation scripts (paired tests, Holm, bootstrap)
- [ ] Executable environment specification validated against actual code
- [ ] README commands for recreating every table and figure
- [ ] Run all commands from a clean environment and verify generated files
